import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.lang.*;

/**
 * <p>Title: HttpdConf.java</p>
 *
 * <p>Description: This class will configure your server to the specifications
 * found within the httpd.conf file. </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: </p>
 * @author Luping May and Tracie Hong
 * @version 1.0
 */
public class HttpdConf {

  /**
   * Default constructor to reset your variables and data structures.
   */
  public HttpdConf(){

  }

  /**
   * Reads in a httpd.conf file, parses it and saves the data stored within that
   * file. This allows for proper configuration of your server since the
   * information stored in your configuration file should allow for your server
   * to function.
   *
   * @param path path to your httpd.conf file
   */
  public void readHttpd(String path){

  }

  /**
   * Function to convert aliases set within your httpd.conf file to their
   * absolute path. This allows for aliases to be found on your server and
   * returned back to the client.
   * HINT: You may find it helpful to create a private class to store your
   * aliases.
   *
   * @param fakeName String which contains the alias of the file or directory
   * @return String value which contains the absolute path to the file or
   *   directory as determined within the httpd.conf file
   */
  public String solveAlias(String fakeName){

  }

  /**
   * Used to read the mime.types file and save all the information from that file
   * into a data structure that can be used to validate file types when
   * generating response messages.
   *
   * @param path String value of path to mime.types file
   */
  public void readMIME (String path) {

  }

  /**
   * Helper function to determine whether the name of a file or directory is an
   * alias for another file or directory as noted in the httpd.conf file.
   *
   * @param name String value of the alias we want to check to determine
   *   whether it is or is not an alias for another file or directory
   * @return true if it is an alias, false otherwise
   */
  public boolean isScript(String name)	{

  }

  /**
   * Helper function to see if you've parsed your httpd.conf file properly. Used
   * for debugging purposes.
   */
  public void testPrint(){
    System.out.println("ServerRoot: "+serverRoot);
    System.out.println("DocumentRoot: "+documentRoot);
    System.out.println("ListenPort: "+listen);
    System.out.println("LogFile: "+logFile);
    System.out.println("AccessFileName: " + accessFileName);
    System.out.println("ScriptAlias: "+scriptAlias+" "+solveAlias(scriptAlias));
  }
}
