This set of files is designed to get you started on your web server project.
It contains classes and functions that can be used to implement your server. Please note you are
not required to use these classes if you would prefer to implement the assignment differently.
You will still be required to design and implement the server using these classes and functions
as we have not included any variable names and very few private functions (e.g. accessor functions).


We have also included a set of sample configuration files and helper classes that you can use as well.

Questions are more than welcome and we will be happy to help you with your project.

Good Luck! :)